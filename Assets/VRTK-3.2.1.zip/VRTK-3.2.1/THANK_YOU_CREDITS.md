# Thank You Credits

A big thank you to the supporters of VRTK via the VRTK Patreon page at https://www.patreon.com/vrtk

### Professional Sponsors

[![image](https://user-images.githubusercontent.com/1029673/27898738-28f0e226-621f-11e7-9fdb-8618d85ba372.png)](https://www.realestate.com.au) 

### Name List

 * **realestate.co.au - Luke Chadwick** *[Professional Sponsor]*
 * Mark Bradley
 * TreeFortress Games
 * BinaryLegend 
 * Eric 
 * Tuukka Takala
 * Mcdoogleh 
 * Matt Ostgard
 * cognitiveVR 
 * Adam Salmi
 * Tanner Ochel
 * Agatha Yu
 * Aldis Sipolins
 * Michael Hurley
 * Carl Wolsey
 * Stephen Eisenhauer
 * Daniel Shimmyo
 * Chris Ross
 * Jedrzej Jonasz
 * Jonathan Linowes
 * jamie hurt
 * Tim Lobes
 * Chris Tuminello
 * Thomas Kildren
 * Devon Grandahl
 * Victor Lew
 * Jeff Canavan
 * Eric Vander Wal
 * Francis Sutton
 * Grayson Deitering
 * mori 
 * TigerLily 
 * Roland 
 * Michal VRoblewski
 * Chris Kirby
 * Trevor Gibbons
 * ManBearPig 
 * Kenneth Lemieux
 * Josh Leong
 * Joey Parr
 * Axel dabee
 * braden 
 * Andy Baker
 * Ben McNelly
 * Ian McNab
 * David Erosa
 * Juho Salonen
 * Casual Immersions Entertainment
 * Jarrell Norwood
 * Steve Weintraut
 * Stephen Elkins
 * David 
 * Matthew Boynton
 * Bartek Tułodziecki
 * Kyle Mausser
 * Niklas Dennerståhl
 * Luke Pierson
 * Balazs Faludi
 * Will Lingard
 * Joe Ferguson
 * Adam Tannir
