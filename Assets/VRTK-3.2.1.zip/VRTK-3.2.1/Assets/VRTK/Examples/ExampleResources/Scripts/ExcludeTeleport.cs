﻿namespace VRTK.Examples
{
    using UnityEngine;

    public class ExcludeTeleport : MonoBehaviour
    {
    }
}